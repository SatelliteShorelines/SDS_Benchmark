function [output,errorvariance] = vebykOnGrid(coord,points,anisotropy,alpha,nu,range,crossv,grille,verbose)

% Value Estimation BY Kriging:
% estimates values on a grid using ordinary kriging.
% 
% Parameters are ment as following:
% 'coord' = [x1 y1 value1;x2 y2 value2...]
% 'grid' = [xi yi] distances between two points on the interpolated grid
% 'points' is the number of points used for interpolation
% 'anisotropy' = (range x) / (range y)
% 'alpha' angle between axis and anisotropy in degrees
% 'nu' for the von karman covariance function.
% 'range' of the covariance function
% 'crossv' = 1 for crossvalidation; for normal operating set 'crossv' = 0
% 'verbose' = 1 for waitbar; = 0 without waitbar
%
% usage:    [output,errorvariance] = vebyk(coord,dgrid,points,anisotropy,alpha,nu,range,crossv,verbose)

% 12.6.2003 Rolf Sidler V 1.0

% changing coordinate system for anisotropy on an angle different from 0
alpha = pi/180 * alpha;
coord = rotation(coord,alpha);
grille = rotation(grille,alpha);
grille = grille(:,1:2);
newgrille = zeros(size(grille,1),3);
errorvariance = zeros(size(grille,1),3);
errorvariance(:,1:2) = grille(:,1:2);
newgrille(:,1:2) = grille(:,1:2);

% waitbar
if verbose
    h = waitbar(0,'Krigging interpolation...');
end

for i = 1:size(grille,1)
    % waitbar
    if verbose
        waitbar(i/size(grille,1),h)
    end
    % calculating the lags of the 'points' next points
    % (change to 'neighborhood2' to use points out of all four quadrants)
    % (change to 'neighborhood' to use simple search neighborhood)
    [values,position] = neighborhood(grille(i,1),grille(i,2),coord,points,crossv,anisotropy);
        
    % kriging
    [lambda,errorvariance(i,3)] = kriging3(position,anisotropy,nu,range);
    
    % calculating the interpolatet value
    newgrille(i,3) = sum(lambda(1:end-1) .* values');
end

% waitbar
if verbose
    close(h)
end

% changing coordinates back
output = rotation(newgrille,(-alpha));
errorvariance = rotation(errorvariance,(-alpha));