function [lambda,errorvariance] = kriging3(position,anisotropy,nu,range)

% kriging is an algorithm for interpolation based on minimation of the
% variances. it is based on a model for the covariances. 'lags' is a vector containing the
% distances between the related values and the point to interpolate. kriging3 calculates
% the factors for the related values. the interpolated value is the sum of the related values
% each multiplied with lambda. 
% kriging3 is for use with an anisotropy factor
%
% usage: [lambda,errorvariance] = kriging3(position,anisotropy,nu,range)
%
% Rolf Sidler 5.6.03
%--------------------------------------------------------------------------
% 2012/10/25 | Marieu | Changed matrix inversion for conditionning issues
%--------------------------------------------------------------------------

% calculating the kriging factors
[C] = buildbigc3(position,anisotropy,nu,range);
[c] = buildsmallc3(position,anisotropy,nu,range);
% comment out next line to use simple kriging
[C,c] = ordinary(C,c);

% calculating the solution to the equation C.lambda=c'
%[lambda] = C\c';
tolerance = max(size(C))*norm(C)*1e-12;
lambda = pinv(C,tolerance)*c';



errorvariance = covcalc(0,nu,range)-sum(lambda.*c');