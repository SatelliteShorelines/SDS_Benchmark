% Generate_DEM.m
% Create a Digital Evelation model from raw data using anisotropic 
% kriging - The code uses a number functions located in the folder
% "Functions_interpoloation" to include in your path
% Vincent Marieu & Bruno Castelle (CNRS / Univ. Bordeaux) 
% Last modified 7/10/2020

clear all
close all

% Define anisotropy  / kriging parameters
RatioAnisotropy = 10;  
AngleAnisotropy = 90;
NbPointsForKriging = 10;     
DistMaxSearchPoints = 150;   
DistMaxClosestPointForNaN = 50; 
Nu = 0.7;

% NetCDF data file to be read
Filename='../Monitoring_TrucVert_2019-09-03.nc' 

% Load data
xl=ncread(Filename,'xl');
yl=ncread(Filename,'yl');
z=ncread(Filename,'z');
zg=ncread(Filename,'zg');
GridFile='../Grids.nc';
xlg=ncread(GridFile,'xlg');
ylg=ncread(GridFile,'ylg');

% Perform Anisotropic krigging
[Nx,Ny]=size(xlg);
XYZ = [xl yl z];
Grid_(:,1) = reshape(xlg,Nx*Ny,1);
Grid_(:,2) = reshape(ylg,Nx*Ny,1);
[XYZ,toto] = vebykOnGrid(XYZ,NbPointsForKriging,RatioAnisotropy,...
             AngleAnisotropy,Nu,DistMaxClosestPointForNaN,0,Grid_,1);
zg_interp = reshape(XYZ(:,3),Nx,Ny);

% In order to disregard interpolated data away from the survey zone, it
% is advised to use a mask, see below
load ZONE_190903.mat
IN=inpolygon(xlg,ylg,xzone,yzone);
zg_interp(IN==0)=NaN;

% Plot DEM in local coordinate system
figure; 
pcolor(xlg,ylg,zg_interp);shading interp;colorbar
xlabel('Cross-shore distance (m)')
ylabel('Alongshore distance (m)')
title('Truc Vert DEM 03/09/2019 in local coordinate system ')

% Plot DEM in local coordinate system
xg=ncread(GridFile,'xg');
yg=ncread(GridFile,'yg');
figure; 
pcolor(xg,yg,zg_interp);shading interp;colorbar;axis equal
xlabel('Easting RGF93 (m)')
ylabel('Northing RGF93 (m)')
title('Truc Vert DEM 03/09/2019 in RGF93 coordinate system ')
